import numpy as np


def RouletteWheelSelection(P):
    r = np.random.rand()
    C = np.cumsum(P)
    return np.nonzero(r <= C)[0][0]


def check_bound(arr, lb, ub):
    arr = np.where(arr < lb, lb, arr)
    arr = np.where(arr > ub, ub, arr)
    return arr
