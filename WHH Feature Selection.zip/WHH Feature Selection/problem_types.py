import numpy as np


class Individual:
    def __init__(self, nVar):
        self.Position = np.zeros(nVar)
        self.Cost = np.inf
        self.Velocity = np.zeros(nVar)
        self.Best_Position = np.zeros(nVar)
        self.Best_Cost = np.inf


class Problem:
    def __init__(self):
        # Number of Decision Variables
        self.nVar = 0
        # Decision Variables Matrix Size
        self.VarSize = self.nVar
        # Decision Variables Lower Bound
        self.VarMin = 0
        # Decision Variables Upper Bound
        self.VarMax = 0
        self.MaxIt = 0
        self.nPop = 0
        self.CostFunction = None
        self.BestSol = Individual(self.nVar)
        self.GlobalBest = Individual(self.nVar)
        self.BestCostMaxiter = np.zeros(self.MaxIt)
        self.BestCost = np.zeros(self.MaxIt)
        self.WorstCost = 0
