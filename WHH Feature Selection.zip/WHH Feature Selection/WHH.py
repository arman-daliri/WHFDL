import copy
import numpy as np

from problem_types import Individual
from BBO import BBO
from DE import DE
from FireFly import FireFly
from HS import HS
from PSO import PSO
from SA import SA
from IWO import IWO
from TLBO import TLBO


class WHH:
    def __init__(self, n):
        self.algnum = n

    def set_parameters(self, problem):
        self.nVar = problem.nVar
        self.VarSize = problem.VarSize
        self.VarMin = problem.VarMin
        self.VarMax = problem.VarMax
        self.MaxIt = problem.MaxIt
        self.nPop = problem.nPop
        self.CostFunction = problem.CostFunction
        self.calls = {}
        self.algs_set(problem)
        self.algs_set_parameters(problem)
        self.first_run_flag = 0
        self.nAlg = len(self.algs)
        self.RLAlpha = 0.5
        self.BestSol = Individual(0)
        self.GlobalBest = Individual(problem.nVar)
        self.BestCostMaxiter = np.zeros(problem.MaxIt)
        self.BestCost = np.zeros(self.nAlg)
        self.WorstCost = 0
        self.lotCHList = np.array([])
        self.iterr = 0

    def algs_set(self, problem):
        a = [
            BBO,
            DE,
            FireFly,
            HS,
            PSO,
            SA,
            TLBO,
            IWO,
        ]
        self.algs = []
        for i in range(len(a)):
            self.algs.append(a[i](i))
            self.calls[self.algs[-1].__class__.__name__] = 0

    def algs_set_parameters(self, problem):
        for alg in self.algs:
            alg.set_parameters(problem)

    def first_run(self, problem, pop):
        for alg in self.algs:
            newpop = copy.deepcopy(pop)
            alg.run(self, pop, newpop)
            self.calls[alg.__class__.__name__] += 1

            # Update Best Cost
            self.BestCost[alg.algnum] = self.BestSol.Cost
            rewardTemp = self.BestSol.Cost - (-1)
            if rewardTemp > 0:
                alg.rewards = 1 / rewardTemp
            else:
                alg.rewards = abs(rewardTemp)

        return sorted(self.algs, key=lambda a: a.rewards)

    def run(self, problem, pop, newpop):
        if not self.first_run_flag:
            self.algs = self.first_run(problem, pop)
            self.first_run_flag = 1

        chooseRandomic = np.random.rand(1)
        sumRewards = 0
        for i in range(self.nAlg):
            sumRewards = sumRewards + self.algs[i].rewards

        rewardsAve = sumRewards / self.nAlg

        if self.iterr < self.nAlg:
            numi = self.iterr
        elif chooseRandomic > self.RLAlpha:
            numi = np.random.randint(0, self.nAlg)
        elif chooseRandomic < self.RLAlpha:
            f = np.cumsum([i.rewards for i in self.algs])
            r = np.random.rand()
            if r > f[-1]:
                numi = f.size - 1
            else:
                numi = np.nonzero(r <= f)[0][0]

        lotCH = self.algs[numi].algnum
        self.lotCHList = np.append(self.lotCHList, lotCH)

        newpop = copy.deepcopy(pop)
        self.algs[numi].run(self, pop, newpop)
        self.calls[self.algs[numi].__class__.__name__] += 1

        self.BestCostMaxiter[self.iterr] = self.BestSol.Cost
        if self.iterr == 0:
            rewardsTemp = self.BestSol.Cost - (-1)
            if rewardsTemp > 0:
                self.algs[lotCH].rewards = 1 / rewardsTemp
            else:
                self.algs[lotCH].rewards = abs(rewardsTemp)
        elif self.iterr > 11 and self.BestCostMaxiter[self.iterr - 1] == self.BestCostMaxiter[self.iterr]:
            self.algs[lotCH].rewards = self.algs[lotCH].rewards - rewardsAve

        else:
            self.algs[lotCH].rewards = self.algs[lotCH].rewards + \
                abs(self.BestCostMaxiter[self.iterr] - self.BestCostMaxiter[self.iterr - 1])

        self.RLAlpha = self.RLAlpha + (1 / self.MaxIt)
        self.algs = np.array(sorted(self.algs, key=lambda a: a.rewards))
        self.BestSolPerIter = self.BestSol

        self.iterr += 1
        problem.BestSol = copy.deepcopy(self.BestSol)
